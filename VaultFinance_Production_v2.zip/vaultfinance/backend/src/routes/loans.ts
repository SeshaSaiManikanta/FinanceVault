// VaultFinance — Loan Routes
import { Router } from 'express';
import { authenticate, requireActiveUser } from '../middleware/auth';
import { listLoans, getLoan, createLoan, getRepaymentSchedule, recordPayment } from '../controllers/loanController';
const router = Router();
router.use(authenticate, requireActiveUser);
router.get('/', listLoans);
router.post('/', createLoan);
router.get('/:id', getLoan);
router.get('/:id/schedule', getRepaymentSchedule);
router.post('/:loanId/repayments/:repaymentId/pay', recordPayment);
export default router;
